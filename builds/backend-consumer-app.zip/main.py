import os

import boto3
import jwt
import requests
from boto3 import client
from botocore.exceptions import ClientError
from flask import (
    Flask,
    redirect,
    render_template,
    request,
    send_from_directory,
    session,
)
from requests.auth import HTTPBasicAuth

from logger import LOG

app = Flask(__name__)
app.logger = LOG
app.secret_key = os.getenv("APPSECRET", "secret")


# These two lines enable debugging at httplib level (requests->urllib3->http.client)
# You will see the REQUEST, including HEADERS and DATA,
# and RESPONSE with HEADERS but without DATA.
# The only thing missing will be the response.body which is not logged.
try:
    import http.client as http_client
except ImportError:
    # Python 2
    import httplib as http_client

http_client.HTTPConnection.debuglevel = 1

# You must initialize logging, otherwise you'll not see debug output.
# logging.basicConfig()
# logging.getLogger().setLevel(logging.DEBUG)
# requests_log = logging.getLogger("requests.packages.urllib3")
# requests_log.setLevel(logging.DEBUG)
# requests_log.propagate = True

client_id = os.getenv("CLIENT_ID")
cognito_domain = os.getenv("COGNITO_DOMAIN")
client_secret = os.getenv("CLIENT_SECRET")
redirect_host = os.getenv("REDIRECT_HOST")
bucket_name = os.getenv("BUCKET_NAME")
region = os.getenv("REGION")


def exchange_code_for_tokens(code, code_verifier=None) -> dict:
    """Exchange the authorization code for user tokens.

    Documentation:
    https://docs.aws.amazon.com/cognito/latest/developerguide/token-endpoint.html
    """

    headers = {"Content-Type": "application/x-www-form-urlencoded"}

    payload = {
        "grant_type": "authorization_code",
        "client_id": client_id,
        "redirect_uri": "{}".format(redirect_host),
        "code": code,
    }
    token_endpoint_url = "https://{}/oauth2/token".format(cognito_domain)

    oauth_response = requests.post(
        token_endpoint_url,
        data=payload,
        headers=headers,
        auth=HTTPBasicAuth(client_id, client_secret),
    )

    oauth_response_body = oauth_response.json()
    # Get the id_token field
    id_token = oauth_response_body["id_token"]

    client = boto3.client("cognito-idp")
    response = client.get_user(AccessToken=oauth_response_body["access_token"])

    session["attributes"] = response["UserAttributes"]

    # Decode the id_token
    # TODO: figure out why verify=False is required.  Why can't signature be verified?
    decoded_id_token = jwt.decode(id_token, "", algorithms=["RS256"], verify=False)

    session["details"] = decoded_id_token
    session["email"] = decoded_id_token["email"]
    session["user"] = decoded_id_token["cognito:username"]

    return oauth_response


@app.route("/js/<path:path>")
def send_js(path):
    return send_from_directory("js", path)


@app.route("/css/<path:path>")
def send_css(path):
    return send_from_directory("css", path)


@app.route("/dist/<path:path>")
def send_dist(path):
    return send_from_directory("dist", path)


@app.route("/assets/<path:path>")
def send_assets(path):
    return send_from_directory("assets", path)


@app.errorhandler(500)
def server_error_500(e):
    app.logger.error(f"Server error: {request.url}")
    return render_template("error.html", error=e), 500


@app.errorhandler(404)
def server_error_404(e):
    app.logger.error(f"Server error: {request.url}")
    return render_template("error.html", error=e), 500


@app.route("/")
@app.route("/index")
def index():

    args = request.args

    if "code" in args:
        oauth_code = args["code"]
        response = exchange_code_for_tokens(oauth_code)
        if response.status_code != 200:
            app.logger.error({"error": "OAuth failed", "response": response})
        return redirect("/")

    if "details" in session:
        return render_template(
            "welcome.html", user=session["user"], email=session["email"]
        )
    else:
        login_url = (
            f"https://{cognito_domain}/oauth2/authorize?"
            f"client_id={client_id}&"
            "response_type=code&"
            f"redirect_uri={redirect_host}&"
            "scope=profile+email+phone+openid+aws.cognito.signin.user.admin"
        )
        return render_template("login.html", login_url=login_url)


@app.route("/logout")
def logout():
    try:
        session.pop("details", None)
        session.pop("email", None)
        session.pop("user", None)
        session.pop("attributes", None)
    except Exception as err:
        app.logger.error(err)

    return redirect(
        "https://{}/logout?client_id={}&logout_uri={}".format(
            cognito_domain, client_id, redirect_host
        )
    )


@app.route("/files")
def files():
    if "details" in session and "attributes" in session:
        files = get_files()

        # TODO sorting

        return render_template(
            "files.html", user=session["user"], email=session["email"], files=files
        )
    else:
        return redirect("/")


def create_presigned_url(object_name, expiration=3600):
    """Generate a presigned URL to share an S3 object

    :param object_name: string
    :param expiration: Time in seconds for the presigned URL to remain valid
    :return: Presigned URL as string. If error, returns None.
    """

    # Generate a presigned URL for the S3 object
    s3_client = boto3.client(
        "s3", region_name=region, config=boto3.session.Config(signature_version="s3v4")
    )
    try:
        response = s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": bucket_name, "Key": object_name},
            ExpiresIn=expiration,
            HttpMethod="GET",
        )
    except ClientError as err:
        app.logger.error(err)
        return None

    # The response contains the presigned URL
    return response


def get_files():

    conn = client(
        "s3", region_name="eu-west-2"
    )  # again assumes boto.cfg setup, assume AWS S3

    file_keys = []
    prefixes = load_user_lookup()

    for prefix in prefixes:
        paginator = conn.get_paginator("list_objects")
        operation_parameters = {"Bucket": bucket_name, "Prefix": prefix}
        page_iterator = paginator.paginate(**operation_parameters)
        for page in page_iterator:
            if "Contents" in page:
                for item in page["Contents"]:
                    if not item["Key"].endswith("/"):
                        file_keys.append({"key": item["Key"], "size": item["Size"]})

    resp = []
    for file_key in file_keys:
        print("User {}: file_key: {}".format(session["user"], file_key["key"]))
        url = create_presigned_url(file_key["key"], 300)
        if url is not None:
            print(
                "User {}: generated url for: {}".format(
                    session["user"], file_key["key"]
                )
            )
            resp.append({"url": url, "key": file_key["key"], "size": file_key["size"]})

    return resp


def return_attribute(attr):
    if "attributes" in session:
        sa = session["attributes"]
        for a in sa:
            if "Name" in a:
                if a["Name"] == attr:
                    return a["Value"]
    return ""


def load_user_lookup():
    paths = []

    is_la = return_attribute("custom:is_la")
    paths_attr = return_attribute("custom:paths")

    path_starts = "wholesaler"
    if is_la == "1":
        path_starts = "local_authority"

    if ";" in paths_attr:
        for loc in paths_attr.split(";"):
            if loc.startswith(path_starts):
                paths.append(loc)
                print("User {}: prefix: {}".format(session["user"], loc))
    elif paths_attr.startswith(path_starts):
        paths.append(paths_attr)
        print("User {}: prefix: {}".format(session["user"], paths_attr))

    return paths


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=os.getenv("PORT", "8000"))
